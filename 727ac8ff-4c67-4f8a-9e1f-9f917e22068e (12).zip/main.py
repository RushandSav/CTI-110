Pat_input = input()

# print the welcome message with name

print("Hello",Pat_input,"and welcome to CS Online!")